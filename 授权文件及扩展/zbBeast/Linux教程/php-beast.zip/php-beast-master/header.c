
/*
 * You can modify this sign to disguise your encrypt file
 */
char encrypt_file_header_sign[] = {
	0xe7, 0x15, 0xa3, 0x0b,
    0xf1, 0xb1, 0x60, 0xed
};

int encrypt_file_header_length = sizeof(encrypt_file_header_sign);
