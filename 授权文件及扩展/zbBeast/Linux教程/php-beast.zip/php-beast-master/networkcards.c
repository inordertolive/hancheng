#include <stdlib.h>

/*
 * Allow network card. if this list empty, this feature was closed!
 */

char *allow_networkcards[] = {
    NULL,
};
