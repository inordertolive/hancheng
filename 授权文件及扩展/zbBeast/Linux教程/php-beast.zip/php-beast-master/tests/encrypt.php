<?php

beast_encode_file('/tmp/test.php', '/tmp/test-encode.php');
